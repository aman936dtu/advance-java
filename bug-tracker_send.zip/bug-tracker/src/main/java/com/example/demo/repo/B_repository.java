package com.example.demo.repo;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface B_repository extends JpaRepository<Details,Integer> {

}
