package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.repo.B_repository;
import com.example.demo.repo.Details;

@Service
public class service {
	
	public List<Details> findByPage(int page, int size){

		PageRequest pageRequest = PageRequest.of(page, size);
		Page<Details> pageResult = repo.findAll(pageRequest);
		if(pageResult.hasContent())
		{
			return pageResult.getContent();
		}
		else
		{
			return new ArrayList<>();
		}

	}
	
	@Autowired
	private B_repository repo;

	public List<Details> findAll(){
		return this.repo.findAll();
	}

	public Optional<Details> findById(int id) {
		Optional<Details> bug=repo.findById(id);
		return bug;	}

	public Details add(Details entity) {
		return this.repo.save(entity);
	}


}
